public class Contact {
    //All hidden properties.
    private String name;
    private String phoneno;
    private String email;
    public Contact(String name, String phoneno){
        this.name = name;
        this.phoneno = phoneno;
        this.email = null;
    }
    public Contact(String name, String phoneno,String email){
        this.name = name;
        this.phoneno = phoneno;
        this.email = email;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setPhoneno(String phoneno){
        this.phoneno = phoneno;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getName(){
        return name;
    }
    public String getEmail(){
        return email;
    }
    public String getPhoneno(){
        return phoneno;
    }
}