import java.util.ArrayList;
import java.util.Scanner;
public class MyContactListApp{
    //Menu
    //1.Create Contact
    //2.View All Contact
    //3.Search Contact.
    //4.Delete Contact
    //Enter Your Choice
    //Exit
    public static void main(String[] args) {
        ContactList contactList = new ContactList();
        Scanner scanner = new Scanner(System.in);
        int menuItemNumber = 0;

        // We have to show input item number at least one time.
        // That's why we use do-while loop, not for loop.
        do{
            menuView();     //for giving input instruction everytime.
            menuItemNumber = scanner.nextInt();
            // System.out.println("You have selected.."+menuItemNumber);
            switch(menuItemNumber){
                case 1:
                    Contact contact = createNewContact(scanner);    //Contact will be created by taking input from user. Then we can into the list.
                    contactList.creatContact(contact);
                    System.out.println("Successfully created...");
                    break;
                case 2:
                    showAllContacts(contactList.getContacts());
                    break;
                case 3:
                    searchList(contactList, scanner);
                    break;
                case 4:
                    deleteContact(contactList, scanner);
                    break;
                case 5:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Please Select a Number between 1-5..");
                    break;
            }
            
        } while (menuItemNumber != 5);
    }
    //view Menu method.
    private static void menuView() {
        System.out.println(String.format("%5s%3s%s", "1.", " ", "Create New Contact"));
        System.out.println(String.format("%5s%3s%s", "2.", " ", "View All Contact"));
        System.out.println(String.format("%5s%3s%s", "3.", " ", "Search Contact"));
        System.out.println(String.format("%5s%3s%s", "4.", " ", "Delete Contact"));
        System.out.println(String.format("%5s%3s%s", "5.", " ", "Exit"));
        System.out.println("---------------------------");
        System.out.print(" Enter Your Choice : ");
    }

    //Get Input from user and Create new contact.
    private static Contact createNewContact(Scanner scanner){
        String name,phone,email;
        Contact contact;    //declearation of a variable.
        scanner.nextLine();     //pause one portion then go step by step.
        System.out.println("Fill the bellow form correctly");
        System.out.print("Enter Your Name: ");
        name = scanner.nextLine();
        System.out.print("Enter Your Phone Number: ");
        phone = scanner.nextLine();
        System.out.print("Enter Email (Type N/A if not available): ");
        email = scanner.nextLine();

        if(email.equalsIgnoreCase("n")){
            contact = new Contact(name, phone);
        }else{
            contact = new Contact(name, phone,email);
        }
        //After creating contact ->
        return contact;
    }
    // ShowAllContact method
    private static void showAllContacts(ArrayList<Contact>contacts){
        System.out.println("All Contacts...");
        //for each loop
        int i = 0;
        for (Contact contact : contacts) {
            String email = contact.getEmail();
            System.out.println(String.format("%-5d%-20s%-15s%-50s", i++, contact.getName(), contact.getPhoneno(), email == null ? "N/A": email));
        }
        System.out.println("----------------------------");
    }
    //searchList method
    private static void searchList(ContactList contactList, Scanner scanner){
        scanner.nextLine();
        System.out.println("Search a name: ");
        String name = scanner.nextLine();
        Contact contact = contactList.searchContact(name);
        if(contact != null){
            String email = contact.getEmail();
            System.out.println(String.format("%-20s%-15s%-50s", contact.getName(), contact.getPhoneno(), email == null ? "N/A": email));
        }else {
            System.out.println("Contacts Not Found...");
        }
    }
    //deleteContact method.
    private static void deleteContact(ContactList contactList, Scanner scanner){
        showAllContacts(contactList.getContacts());
        System.out.print("Enter Index No: ");
        int index = scanner.nextInt();
        contactList.removeContact(index);
        System.out.println("Successfully Removed...");
    }
}
