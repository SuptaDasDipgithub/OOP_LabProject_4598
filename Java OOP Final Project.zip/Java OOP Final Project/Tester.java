public interface Tester {
    public void creatContact();
    public void removeContact();
}