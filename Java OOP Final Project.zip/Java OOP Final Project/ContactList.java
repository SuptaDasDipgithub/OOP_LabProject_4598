import java.util.ArrayList;
public class ContactList{
    //Contact[] cont = new Contact[100]; => We don't use this beacause of limitations.
    //we use arraylist
    private ArrayList<Contact>contacts;
    //use constructor
    public ContactList(){
        contacts = new ArrayList<>();
    }
    public void creatContact(Contact contact){
        contacts.add(contact);
    }
    //how many contacts add.
    public int getTotalContact(){
        return contacts.size();
    }
    public void removeContact(int index){
        contacts.remove(index);
    }
    //search method basically returns contact object.
    public Contact searchContact(String name){
        for(Contact c : contacts){
            if(c.getName().equalsIgnoreCase(name)){
                return c;
            }
        }
        return null;
    }
    public ArrayList<Contact>getContacts(){
        return contacts;
    }
}
